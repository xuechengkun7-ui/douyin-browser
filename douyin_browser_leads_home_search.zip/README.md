# 抖音浏览器：任务 1

本包包含 Flutter 的 pubspec.yaml、lib/main.dart 和 AndroidManifest.xml。它不是预编译 APK。

1. 在安装 Flutter >=3.24、Android SDK 的电脑上运行 `flutter create --platforms=android douyin_browser`。
2. 将本包中的三个文件按同名路径覆盖到新工程；保留 flutter create 生成的 Gradle 和 MainActivity 文件。
3. 在工程目录执行 `flutter pub get`，连接 Android 手机并开启 USB 调试，然后 `flutter run`。
4. 生成安装包：`flutter build apk --release`，产物位于 `build/app/outputs/flutter-apk/app-release.apk`。

WebView 使用设备自带的移动端 User-Agent。Cookie 和网页存储默认保留在 App 的 WebView 数据中；卸载 App 或清除应用数据会删除登录状态，网站本身也可能要求重新登录。不要把抖音密码或模型 API 密钥写入前端脚本。

JSBridge 验证：在自己控制的测试网页里，网页准备好后执行 `window.flutter_inappwebview.callHandler('appBridge', 'hello')`，App 会弹出短消息。Bridge 回调会被当前加载的任何网页调用，因此当前只做无权限的诊断功能。抖音网页版是否允许 WebView 登录取决于网站当时的策略。

## 无电脑：通过 GitHub Actions 打包

在 GitHub 新建仓库，上传本工程的 `pubspec.yaml`、`lib/main.dart`、`android/app/src/main/AndroidManifest.xml` 和 `.github/workflows/build-apk.yml`，保持原目录结构。进入仓库 Actions → Build Android APK → Run workflow。构建结束后在该运行页面的 Artifacts 中下载 `douyin-browser-apk`，解压得到 APK。GitHub 网页上传文件时需要逐个指定目录路径；如果可以用 GitHub 网页编辑器，创建上述四个同名文件也可以。此 APK 使用默认调试用途的发布签名，仅供自用测试，正式发布前需配置自己的签名密钥。
# 抖音网页版登录

启动后以电脑版视图打开 https://www.douyin.com/，尝试自动点击网页上的「登录」，显示抖音自己的登录窗口。没有手机版、电脑版或线索版按钮；主页按钮返回抖音网页版。登录窗口的实现由抖音控制，若网站调整按钮或限制内置 WebView，可能需要手动点击网页上的「登录」，或在三星浏览器登录。

针对手机窄屏仅出现验证码登录的情况，抖音网页会以固定的桌面宽度显示，尝试让官方登录窗口提供扫码选项。能否展示二维码取决于抖音网页和 Android WebView；扫码需要另一台已登录抖音的设备。

# 地址栏搜索

地址栏支持输入网址、粘贴网页链接，也支持直接输入关键词并使用百度搜索。

# 评论线索初版

打开抖音作品及评论区后，点「分析当前评论」。当前版本只读取页面中已经加载的可见评论文本，按询价、购车意向、车型和运营需求等关键词排序，并给出可供人工修改的回复建议。它不会自动关注、发送私信或持续抓取后台数据，也未接入 OpenAI API。抖音网页布局变更或评论未加载时，可能识别不到内容。
