# 抖音浏览器：任务 1

本包包含 Flutter 的 pubspec.yaml、lib/main.dart 和 AndroidManifest.xml。它不是预编译 APK。

1. 在安装 Flutter >=3.24、Android SDK 的电脑上运行 `flutter create --platforms=android douyin_browser`。
2. 将本包中的三个文件按同名路径覆盖到新工程；保留 flutter create 生成的 Gradle 和 MainActivity 文件。
3. 在工程目录执行 `flutter pub get`，连接 Android 手机并开启 USB 调试，然后 `flutter run`。
4. 生成安装包：`flutter build apk --release`，产物位于 `build/app/outputs/flutter-apk/app-release.apk`。

WebView 使用设备自带的移动端 User-Agent。Cookie 和网页存储默认保留在 App 的 WebView 数据中；卸载 App 或清除应用数据会删除登录状态，网站本身也可能要求重新登录。不要把抖音密码或模型 API 密钥写入前端脚本。

JSBridge 验证：在自己控制的测试网页里，网页准备好后执行 `window.flutter_inappwebview.callHandler('appBridge', 'hello')`，App 会弹出短消息。Bridge 回调会被当前加载的任何网页调用，因此当前只做无权限的诊断功能。抖音网页版是否允许 WebView 登录取决于网站当时的策略。

## 无电脑：通过 GitHub Actions 打包

在 GitHub 新建仓库，上传本工程的 `pubspec.yaml`、`lib/main.dart`、`android/app/src/main/AndroidManifest.xml` 和 `.github/workflows/build-apk.yml`，保持原目录结构。进入仓库 Actions → Build Android APK → Run workflow。构建结束后在该运行页面的 Artifacts 中下载 `douyin-browser-apk`，解压得到 APK。GitHub 网页上传文件时需要逐个指定目录路径；如果可以用 GitHub 网页编辑器，创建上述四个同名文件也可以。此 APK 使用默认调试用途的发布签名，仅供自用测试，正式发布前需配置自己的签名密钥。
# 抖音网页版登录

启动后以电脑版视图打开 https://www.douyin.com/，尝试自动点击网页上的「登录」，显示抖音自己的登录窗口。没有手机版、电脑版或线索版按钮；主页按钮返回抖音网页版。登录窗口的实现由抖音控制，若网站调整按钮或限制内置 WebView，可能需要手动点击网页上的「登录」，或在三星浏览器登录。

# 地址栏搜索

地址栏支持输入网址、粘贴网页链接，也支持直接输入关键词并使用百度搜索。

### 评论采集
进入单个抖音视频并打开评论区，点“采集当前评论”。向下滑动评论区加载更多后可反复采集，按昵称和评论内容去重。点“复制评论”即可粘贴到聊天中；打开另一条视频会清空上一条的缓存。仅处理页面当前可见、已加载的评论；网页结构变化或评论区未显示时可能采集不到，不保证覆盖全部评论。

先点开要采集的单条视频，再点“采集选中视频”。复制内容包括视频链接，以及页面中能读到的评论者昵称、用户主页、主页路径标识和评论文字。“用户标识”来自主页链接路径，不等同于抖音号；页面未提供时显示“未显示”。

新版支持自动采集：先点开单条视频和评论区，再点“自动采集评论”。程序会滚动评论区并累积去重；连续五轮没有新评论、收集到 2000 条、运行 60 轮或用户点“停止采集”时结束。单次最多约一分钟。该功能依赖抖音网页的评论 DOM 和懒加载，无法保证获取平台显示的全部评论，也不会绕过访问限制。
