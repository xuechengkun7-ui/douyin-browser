import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const DouyinBrowserApp());
}

class DouyinBrowserApp extends StatelessWidget {
  const DouyinBrowserApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: '抖音浏览器',
        theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.blue),
        home: const BrowserPage(),
      );
}

class BrowserPage extends StatefulWidget {
  const BrowserPage({super.key});

  @override
  State<BrowserPage> createState() => _BrowserPageState();
}

class _BrowserPageState extends State<BrowserPage> {
  static final WebUri _home = WebUri('https://www.douyin.com/');
  final _address = TextEditingController(text: _home.toString());
  InAppWebViewController? _webView;
  bool _loading = false;
  double _progress = 0;
  final Map<String, String> _comments = {};
  String? _videoKey;
  bool _collecting = false;
  bool _stopCollecting = false;

  Future<void> _collectComments() async {
    if (_collecting) {
      _stopCollecting = true;
      return;
    }
    if (_webView == null) return;
    _stopCollecting = false;
    setState(() => _collecting = true);
    try {
      int unchanged = 0;
      for (int page = 0; page < 60 && !_stopCollecting; page++) {
      final result = await _webView!.evaluateJavascript(source: r'''
        (() => {
          const url = location.href;
          const video = url.match(/\/video\/(\d+)/)?.[1] || '';
          const root = document.querySelector('[data-e2e="comment-list"]') ||
            document.querySelector('[class*="commentList"]') ||
            document.querySelector('[class*="comment-list"]');
          if (!root) return JSON.stringify({url, video, comments: [], scrolled: false});
          const items = [...root.querySelectorAll('[data-e2e="comment-item"], [class*="commentItem"], [class*="comment-item"]')];
          const comments = items.map(item => {
            const name = item.querySelector('[data-e2e="comment-username"], [class*="userName"], [class*="username"]')?.innerText?.trim() || '';
            const body = item.querySelector('[data-e2e="comment-content"], [class*="commentContent"], [class*="comment-content"]')?.innerText?.trim() || '';
            const profile = item.querySelector('a[href*="/user/"]')?.href || '';
            const userId = profile.match(/\/user\/([^/?#]+)/)?.[1] || '';
            return {name, body, profile, userId};
          }).filter(x => x.body.length > 0 && x.body.length < 2000).slice(0, 500);
          const candidates = [root, ...root.querySelectorAll('*')].filter(el =>
            el.scrollHeight > el.clientHeight + 40 && el.clientHeight > 80);
          const scrollBox = candidates.sort((a,b) =>
            (b.scrollHeight - b.clientHeight) - (a.scrollHeight - a.clientHeight))[0];
          if (scrollBox) scrollBox.scrollTop += Math.max(400, scrollBox.clientHeight * 0.85);
          else root.lastElementChild?.scrollIntoView({block: 'end'});
          return JSON.stringify({url, video, comments, scrolled: !!scrollBox});
        })();
      ''');
      final data = jsonDecode(result?.toString() ?? '{}') as Map<String, dynamic>;
      final url = data['url']?.toString() ?? '';
      if (!(Uri.tryParse(url)?.host.endsWith('douyin.com') ?? false)) throw const FormatException('请先打开抖音视频页');
      if (data['video']?.toString().isNotEmpty != true) {
        throw const FormatException('请先点开一条视频');
      }
      final key = url.split('?').first;
      if (_videoKey != key) {
        _comments.clear();
        _videoKey = key;
      }
      final previousCount = _comments.length;
      for (final item in (data['comments'] as List<dynamic>? ?? [])) {
        final value = item as Map<String, dynamic>;
        final body = value['body']?.toString().trim() ?? '';
        final name = value['name']?.toString().trim() ?? '';
        final profile = value['profile']?.toString().trim() ?? '';
        final userId = value['userId']?.toString().trim() ?? '';
        if (body.isNotEmpty) {
          _comments['$profile\u0000$name\u0000$body'] =
              '昵称：${name.isEmpty ? '未显示' : name}\n'
              '用户主页：${profile.isEmpty ? '未显示' : profile}\n'
              '用户标识：${userId.isEmpty ? '未显示' : userId}\n'
              '评论：$body';
        }
      }
      if (!mounted) return;
      setState(() {});
      unchanged = _comments.length == previousCount ? unchanged + 1 : 0;
      if (unchanged >= 5 || _comments.length >= 2000) break;
      await Future<void>.delayed(const Duration(milliseconds: 900));
      }
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(
        _comments.isEmpty ? '未读到评论。请打开视频评论区再试。' :
        '本次已收集 ${_comments.length} 条评论，可复制；未加载或隐藏的评论无法保证采集。',
      )));
    } on FormatException catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.message)),
      );
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('采集失败。请点开视频评论区后重试。')),
      );
    } finally {
      if (mounted) setState(() => _collecting = false);
    }
  }

  Future<void> _copyComments() async {
    if (_comments.isEmpty) return;
    await Clipboard.setData(ClipboardData(text: '视频：${_videoKey ?? ''}\n\n' + _comments.values.join('\n\n')));
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('已复制 ${_comments.length} 条评论，可以粘贴到聊天中')),
    );
  }

  final _settings = InAppWebViewSettings(
    userAgent: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 '
        '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    javaScriptEnabled: true,
    javaScriptCanOpenWindowsAutomatically: true,
    supportMultipleWindows: true,
    domStorageEnabled: true,
    cacheEnabled: true,
    thirdPartyCookiesEnabled: true,
    useShouldOverrideUrlLoading: true,
    useWideViewPort: true,
    loadWithOverviewMode: true,
  );

  Future<void> _showLoginIfAvailable(InAppWebViewController controller, WebUri? url) async {
    if (url?.host != 'www.douyin.com' || url?.path != '/') return;
    // The sign-in window is part of Douyin's page, not a separate stable URL.
    // Click the visible sign-in control only when the account is signed out.
    await controller.evaluateJavascript(source: r'''
      (() => {
        const candidates = [...document.querySelectorAll('button, a, [role="button"]')];
        const login = candidates.find(el =>
          el.getClientRects().length && el.textContent.trim() === '登录');
        if (login) login.click();
      })();
    ''');
  }

  Future<void> _openAddress(String raw) async {
    final text = raw.trim();
    if (text.isEmpty) return;
    final match = RegExp(r'https?://[^\s]+').firstMatch(text);
    final cleaned = (match?.group(0) ?? text)
        .replaceAll(RegExp(r'[，。,.)）]+$'), '');
    final looksLikeAddress = match != null ||
        (!cleaned.contains(RegExp(r'\s')) &&
            RegExp(r'^(localhost|(?:[^./\s]+\.)+[^./\s]+)(?::\d+)?(?:[/?#].*)?$')
                .hasMatch(cleaned));
    final uri = looksLikeAddress
        ? Uri.tryParse(cleaned.contains('://') ? cleaned : 'https://$cleaned')
        : Uri.https('www.baidu.com', '/s', {'wd': text});
    if (uri == null || uri.scheme != 'https' || uri.host.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('请输入搜索内容或有效的 HTTPS 地址')),
        );
      }
      return;
    }
    FocusScope.of(context).unfocus();
    await _webView?.loadUrl(urlRequest: URLRequest(url: WebUri.uri(uri)));
  }

  Future<void> _goBack() async {
    final view = _webView;
    if (view != null && await view.canGoBack()) {
      await view.goBack();
    } else {
      await _openAddress(_home.toString());
    }
  }

  @override
  void dispose() {
    _address.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => PopScope(
        canPop: false,
        onPopInvoked: (didPop) {
          if (!didPop) _goBack();
        },
        child: Scaffold(
          appBar: AppBar(
            title: const Text('抖音浏览器'),
          ),
          body: Column(
            children: [
              Row(
                children: [
                  IconButton(
                    tooltip: '返回上一页',
                    icon: const Icon(Icons.arrow_back),
                    onPressed: _goBack,
                  ),
                  IconButton(
                    tooltip: '抖音网页版首页',
                    icon: const Icon(Icons.home_outlined),
                    onPressed: () => _openAddress(_home.toString()),
                  ),
                  Expanded(
                    child: TextField(
                      controller: _address,
                      keyboardType: TextInputType.url,
                      textInputAction: TextInputAction.go,
                      onSubmitted: _openAddress,
                      decoration: const InputDecoration(
                        hintText: '搜索或输入网址',
                        isDense: true,
                      ),
                    ),
                  ),
                  IconButton(
                    tooltip: '打开网址',
                    icon: const Icon(Icons.arrow_forward),
                    onPressed: () => _openAddress(_address.text),
                  ),
                  IconButton(
                    tooltip: '刷新',
                    icon: const Icon(Icons.refresh),
                    onPressed: () => _webView?.reload(),
                  ),
                ],
              ),
              if (_loading)
                LinearProgressIndicator(value: _progress == 0 ? null : _progress),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TextButton.icon(
                    onPressed: _collectComments,
                    icon: const Icon(Icons.comment_outlined),
                    label: Text(_collecting ? '停止采集' : '自动采集评论'),
                  ),
                  TextButton.icon(
                    onPressed: _comments.isEmpty ? null : _copyComments,
                    icon: const Icon(Icons.copy),
                    label: Text('复制评论 (${_comments.length})'),
                  ),
                ],
              ),
              Expanded(
                child: InAppWebView(
                  initialUrlRequest: URLRequest(url: _home),
                  initialSettings: _settings,
                  onWebViewCreated: (controller) => _webView = controller,
                  shouldOverrideUrlLoading: (_, action) async {
                    final scheme = action.request.url?.scheme.toLowerCase();
                    // Keep app-only redirects from replacing the login page.
                    return scheme == 'https' || scheme == 'http' || scheme == 'about'
                        ? NavigationActionPolicy.ALLOW
                        : NavigationActionPolicy.CANCEL;
                  },
                  onCreateWindow: (controller, action) async {
                    // Douyin may open its sign-in flow in a new WebView window.
                    // Show that URL in the existing browser so Back works.
                    final url = action.request.url;
                    if (url != null && url.scheme == 'https') {
                      await controller.loadUrl(urlRequest: URLRequest(url: url));
                    } else if (mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('此登录方式需要在手机浏览器或抖音 App 中完成')),
                      );
                    }
                    return false;
                  },
                  onUpdateVisitedHistory: (_, url, __) {
                    if (mounted && url != null && url.scheme == 'https') {
                      setState(() => _address.text = url.toString());
                    }
                  },
                  onLoadStart: (_, url) {
                    if (!mounted) return;
                    setState(() {
                      _loading = true;
                      _progress = 0;
                      if (url != null) _address.text = url.toString();
                    });
                  },
                  onLoadStop: (controller, url) {
                    if (!mounted) return;
                    setState(() {
                      _loading = false;
                      _progress = 1;
                      if (url != null) _address.text = url.toString();
                    });
                    _showLoginIfAvailable(controller, url);
                  },
                  onProgressChanged: (_, progress) {
                    if (mounted) setState(() => _progress = progress / 100);
                  },
                  onReceivedError: (_, request, error) {
                    if (request.isForMainFrame != true || !mounted) return;
                    setState(() => _loading = false);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('网页加载失败：${error.description}')),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      );

}
