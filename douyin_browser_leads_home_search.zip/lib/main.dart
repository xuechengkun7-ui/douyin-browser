import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const DouyinBrowserApp());
}

class DouyinBrowserApp extends StatelessWidget {
  const DouyinBrowserApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: '抖音浏览器',
        theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.blue),
        home: const BrowserPage(),
      );
}

class BrowserPage extends StatefulWidget {
  const BrowserPage({super.key});

  @override
  State<BrowserPage> createState() => _BrowserPageState();
}

class _BrowserPageState extends State<BrowserPage> {
  static final WebUri _leadsLogin =
      WebUri('https://leads.cluerich.com/pc/auth/login');
  static final WebUri _home = _leadsLogin;
  final _address = TextEditingController(text: _home.toString());
  InAppWebViewController? _webView;
  bool _loading = false;
  double _progress = 0;
  bool _desktopMode = true;
  String? _defaultUserAgent;

  final _settings = InAppWebViewSettings(
    userAgent: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 '
        '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    javaScriptEnabled: true,
    javaScriptCanOpenWindowsAutomatically: true,
    supportMultipleWindows: true,
    domStorageEnabled: true,
    cacheEnabled: true,
    thirdPartyCookiesEnabled: true,
    useShouldOverrideUrlLoading: true,
    useWideViewPort: true,
    loadWithOverviewMode: true,
  );

  Future<void> _toggleDesktopMode() async {
    final view = _webView;
    if (view == null) return;
    final original = _defaultUserAgent ??
        await InAppWebViewController.getDefaultUserAgent();
    _defaultUserAgent = original;
    final chromeVersion = RegExp(r'Chrome/([0-9.]+)').firstMatch(original)?.group(1)
        ?? '120.0.0.0';
    final nextMode = !_desktopMode;
    _settings.userAgent = nextMode
        ? 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 '
            '(KHTML, like Gecko) Chrome/$chromeVersion Safari/537.36'
        : original;
    await view.setSettings(settings: _settings);
    if (!mounted) return;
    setState(() => _desktopMode = nextMode);
    await _openAddress(_home.toString());
  }

  Future<void> _openLeadsLogin() async {
    final view = _webView;
    if (view == null) return;
    final original = _defaultUserAgent ??
        await InAppWebViewController.getDefaultUserAgent();
    _defaultUserAgent = original;
    final chromeVersion =
        RegExp(r'Chrome/([0-9.]+)').firstMatch(original)?.group(1) ??
            '120.0.0.0';
    _settings.userAgent =
        'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 '
        '(KHTML, like Gecko) Chrome/$chromeVersion Safari/537.36';
    await view.setSettings(settings: _settings);
    if (!mounted) return;
    setState(() => _desktopMode = true);
    await _openAddress(_leadsLogin.toString());
  }

  Future<void> _openAddress(String raw) async {
    final text = raw.trim();
    if (text.isEmpty) return;
    final match = RegExp(r'https?://[^\s]+').firstMatch(text);
    final cleaned = (match?.group(0) ?? text)
        .replaceAll(RegExp(r'[，。,.)）]+$'), '');
    final looksLikeAddress = match != null ||
        (!cleaned.contains(RegExp(r'\s')) &&
            RegExp(r'^(localhost|(?:[^./\s]+\.)+[^./\s]+)(?::\d+)?(?:[/?#].*)?$')
                .hasMatch(cleaned));
    final uri = looksLikeAddress
        ? Uri.tryParse(cleaned.contains('://') ? cleaned : 'https://$cleaned')
        : Uri.https('www.baidu.com', '/s', {'wd': text});
    if (uri == null || uri.scheme != 'https' || uri.host.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('请输入搜索内容或有效的 HTTPS 地址')),
        );
      }
      return;
    }
    FocusScope.of(context).unfocus();
    await _webView?.loadUrl(urlRequest: URLRequest(url: WebUri.uri(uri)));
  }

  Future<void> _goBack() async {
    final view = _webView;
    if (view != null && await view.canGoBack()) {
      await view.goBack();
    } else {
      await _openAddress(_home.toString());
    }
  }

  @override
  void dispose() {
    _address.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => PopScope(
        canPop: false,
        onPopInvoked: (didPop) {
          if (!didPop) _goBack();
        },
        child: Scaffold(
          appBar: AppBar(
            title: const Text('抖音浏览器'),
            actions: [
              TextButton(
                onPressed: _openLeadsLogin,
                child: const Text('线索版登录'),
              ),
              TextButton(
                onPressed: _toggleDesktopMode,
                child: Text(_desktopMode ? '手机版' : '电脑版'),
              ),
            ],
          ),
          body: Column(
            children: [
              Row(
                children: [
                  IconButton(
                    tooltip: '返回上一页',
                    icon: const Icon(Icons.arrow_back),
                    onPressed: _goBack,
                  ),
                  IconButton(
                    tooltip: '抖音首页',
                    icon: const Icon(Icons.home_outlined),
                    onPressed: () => _openAddress(_home.toString()),
                  ),
                  Expanded(
                    child: TextField(
                      controller: _address,
                      keyboardType: TextInputType.url,
                      textInputAction: TextInputAction.go,
                      onSubmitted: _openAddress,
                      decoration: const InputDecoration(
                        hintText: '搜索或输入网址',
                        isDense: true,
                      ),
                    ),
                  ),
                  IconButton(
                    tooltip: '打开网址',
                    icon: const Icon(Icons.arrow_forward),
                    onPressed: () => _openAddress(_address.text),
                  ),
                  IconButton(
                    tooltip: '刷新',
                    icon: const Icon(Icons.refresh),
                    onPressed: () => _webView?.reload(),
                  ),
                ],
              ),
              if (_loading)
                LinearProgressIndicator(value: _progress == 0 ? null : _progress),
              Expanded(
                child: InAppWebView(
                  initialUrlRequest: URLRequest(url: _home),
                  initialSettings: _settings,
                  onWebViewCreated: (controller) => _webView = controller,
                  shouldOverrideUrlLoading: (_, action) async {
                    final scheme = action.request.url?.scheme.toLowerCase();
                    // Keep app-only redirects from replacing the login page.
                    return scheme == 'https' || scheme == 'http' || scheme == 'about'
                        ? NavigationActionPolicy.ALLOW
                        : NavigationActionPolicy.CANCEL;
                  },
                  onCreateWindow: (controller, action) async {
                    // Douyin may open its sign-in flow in a new WebView window.
                    // Show that URL in the existing browser so Back works.
                    final url = action.request.url;
                    if (url != null && url.scheme == 'https') {
                      await controller.loadUrl(urlRequest: URLRequest(url: url));
                    } else if (mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('此登录方式需要在手机浏览器或抖音 App 中完成')),
                      );
                    }
                    return false;
                  },
                  onUpdateVisitedHistory: (_, url, __) {
                    if (mounted && url != null && url.scheme == 'https') {
                      setState(() => _address.text = url.toString());
                    }
                  },
                  onLoadStart: (_, url) {
                    if (!mounted) return;
                    setState(() {
                      _loading = true;
                      _progress = 0;
                      if (url != null) _address.text = url.toString();
                    });
                  },
                  onLoadStop: (_, url) {
                    if (!mounted) return;
                    setState(() {
                      _loading = false;
                      _progress = 1;
                      if (url != null) _address.text = url.toString();
                    });
                  },
                  onProgressChanged: (_, progress) {
                    if (mounted) setState(() => _progress = progress / 100);
                  },
                  onReceivedError: (_, request, error) {
                    if (request.isForMainFrame != true || !mounted) return;
                    setState(() => _loading = false);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('网页加载失败：${error.description}')),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      );

}
