import 'dart:collection';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const DouyinBrowserApp());
}

class DouyinBrowserApp extends StatelessWidget {
  const DouyinBrowserApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: '抖音浏览器',
        theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.blue),
        home: const BrowserPage(),
      );
}

class BrowserPage extends StatefulWidget {
  const BrowserPage({super.key});

  @override
  State<BrowserPage> createState() => _BrowserPageState();
}

class _Lead {
  _Lead(this.comment, this.score, this.reasons);
  final String comment;
  final int score;
  final List<String> reasons;
}

class _BrowserPageState extends State<BrowserPage> {
  static final WebUri _home = WebUri('https://www.douyin.com/');
  final _address = TextEditingController(text: _home.toString());
  InAppWebViewController? _webView;
  bool _loading = false;
  double _progress = 0;

  bool _analyzing = false;

  List<_Lead> _scoreComments(Iterable<String> comments) {
    final rules = <(RegExp, int, String)>[
      (RegExp(r'多少钱|什么价|报价|价格|落地|首付|月供'), 5, '询价'),
      (RegExp(r'想买|准备买|要买|购车|提车|换车|买一台'), 6, '购车意向'),
      (RegExp(r'联系|咨询|私聊|怎么购买|哪里买'), 4, '希望联系'),
      (RegExp(r'牵引车|重卡|新能源|电车|换电|徐工|三一|电池'), 2, '车型相关'),
      (RegExp(r'跑运输|货源|物流|运价|路线|充电|续航|自重'), 2, '运营需求'),
      (RegExp(r'上海|浙江|江苏|安徽'), 1, '目标区域'),
    ];
    final results = <_Lead>[];
    for (final comment in comments) {
      var score = 0;
      final reasons = <String>[];
      for (final (pattern, points, reason) in rules) {
        if (pattern.hasMatch(comment)) {
          score += points;
          reasons.add(reason);
        }
      }
      if (score > 0) results.add(_Lead(comment, score, reasons));
    }
    results.sort((a, b) => b.score.compareTo(a.score));
    return results;
  }

  Future<void> _analyzeVisibleComments() async {
    final controller = _webView;
    if (controller == null || _analyzing) return;
    final uri = await controller.getUrl();
    if (uri == null || !(uri.host == 'douyin.com' || uri.host.endsWith('.douyin.com'))) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请先打开抖音作品的评论区')),
      );
      return;
    }
    setState(() => _analyzing = true);
    try {
      // Read only text already present in the page. Do not scroll, follow,
      // collect hidden data, or send messages on the user's behalf.
      final raw = await controller.evaluateJavascript(source: r'''
        (() => {
          const panels = [...document.querySelectorAll('[class*="comment" i], [data-e2e*="comment" i], [aria-label*="评论"]')]
            .filter(el => el.getClientRects().length && getComputedStyle(el).visibility !== 'hidden');
          const parts = panels.flatMap(el => {
            const children = [...el.querySelectorAll('p, [class*="content" i], [class*="text" i]')];
            return (children.length ? children : [el]).map(node => node.innerText?.trim() || '');
          });
          return JSON.stringify([...new Set(parts.map(s => s.replace(/\s+/g, ' ').trim()))]
            .filter(s => s.length >= 4 && s.length <= 240).slice(0, 200));
        })();
      ''');
      final decoded = jsonDecode(raw is String ? raw : raw.toString());
      final comments = decoded is List
          ? decoded.whereType<String>().toSet().toList()
          : <String>[];
      final leads = _scoreComments(comments);
      if (!mounted) return;
      await showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        builder: (sheetContext) => SafeArea(
          child: SizedBox(
            height: MediaQuery.sizeOf(sheetContext).height * .72,
            child: Column(children: [
              ListTile(
                title: const Text('当前评论中的客户线索'),
                subtitle: Text('读取到 ${comments.length} 条可见文本，匹配 ${leads.length} 条；仅保存在当前页面'),
                trailing: IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.pop(sheetContext)),
              ),
              Expanded(child: leads.isEmpty
                  ? const Center(child: Text('没有找到匹配评论。请打开作品评论区，加载评论后重试。'))
                  : ListView.builder(
                      itemCount: leads.length,
                      itemBuilder: (_, index) {
                        final lead = leads[index];
                        return Card(child: ListTile(
                          title: Text(lead.comment),
                          subtitle: Text('匹配：${lead.reasons.join('、')}\n建议回复：您好，看到您关注${lead.reasons.first}，您主要跑什么路线？我可以按实际运营情况帮您算一笔账。'),
                          isThreeLine: true,
                          trailing: Chip(label: Text('${lead.score}分')),
                        ));
                      },
                    )),
            ]),
          ),
        ),
      );
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('评论读取失败，请打开评论区后重试')),
      );
    } finally {
      if (mounted) setState(() => _analyzing = false);
    }
  }

  final _settings = InAppWebViewSettings(
    userAgent: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 '
        '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    javaScriptEnabled: true,
    javaScriptCanOpenWindowsAutomatically: true,
    supportMultipleWindows: true,
    domStorageEnabled: true,
    cacheEnabled: true,
    thirdPartyCookiesEnabled: true,
    useShouldOverrideUrlLoading: true,
    useWideViewPort: true,
    loadWithOverviewMode: true,
  );

  Future<void> _showLoginIfAvailable(InAppWebViewController controller, WebUri? url) async {
    if (url?.host != 'www.douyin.com' || url?.path != '/') return;
    // The sign-in window is part of Douyin's page, not a separate stable URL.
    // Click the visible sign-in control only when the account is signed out.
    await controller.evaluateJavascript(source: r'''
      (() => {
        const candidates = [...document.querySelectorAll('button, a, [role="button"]')];
        const login = candidates.find(el =>
          el.getClientRects().length && el.textContent.trim() === '登录');
        if (login) login.click();
      })();
    ''');
  }

  Future<void> _openAddress(String raw) async {
    final text = raw.trim();
    if (text.isEmpty) return;
    final match = RegExp(r'https?://[^\s]+').firstMatch(text);
    final cleaned = (match?.group(0) ?? text)
        .replaceAll(RegExp(r'[，。,.)）]+$'), '');
    final looksLikeAddress = match != null ||
        (!cleaned.contains(RegExp(r'\s')) &&
            RegExp(r'^(localhost|(?:[^./\s]+\.)+[^./\s]+)(?::\d+)?(?:[/?#].*)?$')
                .hasMatch(cleaned));
    final uri = looksLikeAddress
        ? Uri.tryParse(cleaned.contains('://') ? cleaned : 'https://$cleaned')
        : Uri.https('www.baidu.com', '/s', {'wd': text});
    if (uri == null || uri.scheme != 'https' || uri.host.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('请输入搜索内容或有效的 HTTPS 地址')),
        );
      }
      return;
    }
    FocusScope.of(context).unfocus();
    await _webView?.loadUrl(urlRequest: URLRequest(url: WebUri.uri(uri)));
  }

  Future<void> _goBack() async {
    final view = _webView;
    if (view != null && await view.canGoBack()) {
      await view.goBack();
    } else {
      await _openAddress(_home.toString());
    }
  }

  @override
  void dispose() {
    _address.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => PopScope(
        canPop: false,
        onPopInvoked: (didPop) {
          if (!didPop) _goBack();
        },
        child: Scaffold(
          appBar: AppBar(
            title: const Text('抖音浏览器'),
          ),
          body: Column(
            children: [
              Row(
                children: [
                  IconButton(
                    tooltip: '返回上一页',
                    icon: const Icon(Icons.arrow_back),
                    onPressed: _goBack,
                  ),
                  IconButton(
                    tooltip: '抖音网页版首页',
                    icon: const Icon(Icons.home_outlined),
                    onPressed: () => _openAddress(_home.toString()),
                  ),
                  Expanded(
                    child: TextField(
                      controller: _address,
                      keyboardType: TextInputType.url,
                      textInputAction: TextInputAction.go,
                      onSubmitted: _openAddress,
                      decoration: const InputDecoration(
                        hintText: '搜索或输入网址',
                        isDense: true,
                      ),
                    ),
                  ),
                  IconButton(
                    tooltip: '打开网址',
                    icon: const Icon(Icons.arrow_forward),
                    onPressed: () => _openAddress(_address.text),
                  ),
                  IconButton(
                    tooltip: '刷新',
                    icon: const Icon(Icons.refresh),
                    onPressed: () => _webView?.reload(),
                  ),
                ],
              ),
              SizedBox(
                width: double.infinity,
                child: TextButton.icon(
                  onPressed: _analyzing ? null : _analyzeVisibleComments,
                  icon: const Icon(Icons.manage_search),
                  label: Text(_analyzing ? '正在分析…' : '分析当前评论'),
                ),
              ),
              if (_loading)
                LinearProgressIndicator(value: _progress == 0 ? null : _progress),
              Expanded(
                child: InAppWebView(
                  initialUrlRequest: URLRequest(url: _home),
                  initialSettings: _settings,
                  initialUserScripts: UnmodifiableListView<UserScript>([
                    UserScript(
                      injectionTime: UserScriptInjectionTime.AT_DOCUMENT_START,
                      source: r'''
                        (() => {
                          if (!/(^|\.)douyin\.com$/.test(location.hostname)) return;
                          const setDesktopViewport = () => {
                            if (!document.head) return;
                            let viewport = document.querySelector('meta[name="viewport"]');
                            if (!viewport) {
                              viewport = document.createElement('meta');
                              viewport.name = 'viewport';
                              document.head.appendChild(viewport);
                            }
                            const desktop = 'width=1280, initial-scale=1';
                            if (viewport.content !== desktop) viewport.content = desktop;
                          };
                          setDesktopViewport();
                          const observer = new MutationObserver(setDesktopViewport);
                          observer.observe(document, {
                            subtree: true, childList: true, attributes: true,
                            attributeFilter: ['content']
                          });
                          setTimeout(() => observer.disconnect(), 30000);
                        })();
                      ''',
                    ),
                  ]),
                  onWebViewCreated: (controller) => _webView = controller,
                  shouldOverrideUrlLoading: (_, action) async {
                    final scheme = action.request.url?.scheme.toLowerCase();
                    // Keep app-only redirects from replacing the login page.
                    return scheme == 'https' || scheme == 'http' || scheme == 'about'
                        ? NavigationActionPolicy.ALLOW
                        : NavigationActionPolicy.CANCEL;
                  },
                  onCreateWindow: (controller, action) async {
                    // Douyin may open its sign-in flow in a new WebView window.
                    // Show that URL in the existing browser so Back works.
                    final url = action.request.url;
                    if (url != null && url.scheme == 'https') {
                      await controller.loadUrl(urlRequest: URLRequest(url: url));
                    } else if (mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('此登录方式需要在手机浏览器或抖音 App 中完成')),
                      );
                    }
                    return false;
                  },
                  onUpdateVisitedHistory: (_, url, __) {
                    if (mounted && url != null && url.scheme == 'https') {
                      setState(() => _address.text = url.toString());
                    }
                  },
                  onLoadStart: (_, url) {
                    if (!mounted) return;
                    setState(() {
                      _loading = true;
                      _progress = 0;
                      if (url != null) _address.text = url.toString();
                    });
                  },
                  onLoadStop: (controller, url) {
                    if (!mounted) return;
                    setState(() {
                      _loading = false;
                      _progress = 1;
                      if (url != null) _address.text = url.toString();
                    });
                    _showLoginIfAvailable(controller, url);
                  },
                  onProgressChanged: (_, progress) {
                    if (mounted) setState(() => _progress = progress / 100);
                  },
                  onReceivedError: (_, request, error) {
                    if (request.isForMainFrame != true || !mounted) return;
                    setState(() => _loading = false);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('网页加载失败：${error.description}')),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      );

}
