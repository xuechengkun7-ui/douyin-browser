import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const DouyinBrowserApp());
}

class DouyinBrowserApp extends StatelessWidget {
  const DouyinBrowserApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: '抖音浏览器',
        theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.blue),
        home: const BrowserPage(),
      );
}

class BrowserPage extends StatefulWidget {
  const BrowserPage({super.key});

  @override
  State<BrowserPage> createState() => _BrowserPageState();
}

class _BrowserPageState extends State<BrowserPage> {
  static final WebUri _home = WebUri('https://www.douyin.com/');
  final TextEditingController _address =
      TextEditingController(text: _home.toString());
  InAppWebViewController? _webView;
  double _progress = 0;
  bool _loading = false;

  // Keep the default Android WebView user agent: it matches the installed
  // WebView engine and is generally more compatible than a hardcoded version.
  final InAppWebViewSettings _settings = InAppWebViewSettings(
    javaScriptEnabled: true,
    domStorageEnabled: true,
    cacheEnabled: true,
    thirdPartyCookiesEnabled: true,
  );

  void _openAddress(String raw) {
    final value = raw.trim();
    final parsed = Uri.tryParse(value.contains('://') ? value : 'https://$value');
    if (parsed == null || parsed.scheme != 'https' || parsed.host.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请输入有效的 HTTPS 地址')),
      );
      return;
    }
    _webView?.loadUrl(urlRequest: URLRequest(url: WebUri.uri(parsed)));
    FocusScope.of(context).unfocus();
  }

  @override
  void dispose() {
    _address.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('抖音浏览器')),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _address,
                      keyboardType: TextInputType.url,
                      textInputAction: TextInputAction.go,
                      onSubmitted: _openAddress,
                      decoration: const InputDecoration(
                        hintText: '输入 HTTPS 地址',
                        isDense: true,
                      ),
                    ),
                  ),
                  IconButton(
                    tooltip: '打开',
                    icon: const Icon(Icons.arrow_forward),
                    onPressed: () => _openAddress(_address.text),
                  ),
                  IconButton(
                    tooltip: '刷新',
                    icon: const Icon(Icons.refresh),
                    onPressed: () => _webView?.reload(),
                  ),
                ],
              ),
            ),
            if (_loading)
              LinearProgressIndicator(value: _progress == 0 ? null : _progress),
            Expanded(
              child: InAppWebView(
                initialUrlRequest: URLRequest(url: _home),
                initialSettings: _settings,
                onWebViewCreated: (controller) {
                  _webView = controller;
                  controller.addJavaScriptHandler(
                    handlerName: 'appBridge',
                    callback: (args) {
                      // Never accept commands or secrets from an arbitrary page.
                      // This task only displays a short diagnostic message.
                      final message = args.isNotEmpty ? args.first.toString() : '';
                      if (mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('网页消息: ${message.length > 80 ? message.substring(0, 80) : message}')),
                        );
                      }
                      return {'received': true};
                    },
                  );
                },
                onLoadStart: (_, url) {
                  if (!mounted) return;
                  setState(() {
                    _loading = true;
                    _progress = 0;
                    if (url != null) _address.text = url.toString();
                  });
                },
                onLoadStop: (_, url) {
                  if (!mounted) return;
                  setState(() {
                    _loading = false;
                    _progress = 1;
                    if (url != null) _address.text = url.toString();
                  });
                },
                onProgressChanged: (_, progress) {
                  if (mounted) setState(() => _progress = progress / 100);
                },
                onReceivedError: (_, request, error) {
                  if (!request.isForMainFrame || !mounted) return;
                  setState(() => _loading = false);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('加载失败: ${error.description}')),
                  );
                },
              ),
            ),
          ],
        ),
      );
}
